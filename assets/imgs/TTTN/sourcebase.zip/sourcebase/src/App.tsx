import React, { Suspense } from 'react';
import { createBrowserHistory } from 'history';
import RootWrapper from './wrappers/RootWrapper';
import { Router } from 'react-router-dom';
import { QueryClientProvider, QueryClient } from 'react-query';
import { ReactQueryDevtools } from 'react-query/devtools';
import configs from 'config';
import dayjs from 'dayjs'
import { ConfigProvider } from 'antd';
import ja_JP from 'antd/lib/locale/ja_JP';
import PopupConfirm from './components/PopupConfirm';
require('dayjs/locale/ja')
dayjs.locale('ja')
export const history = createBrowserHistory();
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      cacheTime: 24 * 3600 * 1000, // cache for 1 day
      retry: false,
    },
  },
});
function App() {
  return (
    <ConfigProvider locale={ja_JP}>
      <QueryClientProvider client={queryClient}>
        <Router history={history}>
          <Suspense fallback={null}>
            <RootWrapper />
          </Suspense>
        </Router>
        {configs.APP_ENV !== 'prod' && <ReactQueryDevtools initialIsOpen={false} />}
      </QueryClientProvider>
      <PopupConfirm/>
    </ConfigProvider>
  );
}

export default App;
