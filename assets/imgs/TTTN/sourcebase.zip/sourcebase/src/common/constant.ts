export enum STATUS {
  ACTIVE = 1,
  INACTIVE = 0,
}

export default {
 DATE_PICKER_TITLE: 'YYYY年MM月'
}