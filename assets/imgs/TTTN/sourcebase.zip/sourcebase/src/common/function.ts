export function example() {
  console.log('hello');
}