import React, { useEffect, useState } from 'react';
import { useHistory } from 'react-router-dom';
import styles from './styles.module.scss';
import { useTranslation } from 'react-i18next';
import dayjs from 'dayjs';
import {Dayjs} from 'dayjs';
import dayjsGenerateConfig from 'rc-picker/lib/generate/dayjs';
import generateCalendar from 'antd/es/calendar/generateCalendar';
import 'antd/lib/locale/ja_JP';
import prevImg from 'assets/images/prev.svg';
import nextImg from 'assets/images/next.svg';
import generatePicker from 'antd/es/date-picker/generatePicker';
import common from 'common/constant';

export default function MonthCalendar() {

  const {t} = useTranslation();
  const Calendar = generateCalendar<Dayjs>(dayjsGenerateConfig);
  const DatePicker = generatePicker<Dayjs>(dayjsGenerateConfig);
  const [currentDate, setCurrentDate] = useState(dayjs())
  // let minYear = dayjs('2000')
  // let maxYear = dayjs('3000')
  

  const dateCellRender = (value:any) => {
    return value !== dayjs(new Date()) &&
      (
       <div>data</div>
      );
    }

  const onPanelChange = (value:any) => {}

  const disableDate = (value: any) => {
    return value.month() !== currentDate.month() 
  }

  const changeDate = (value: any) => {
    setCurrentDate(value)
  }

  const onSelect = (value: any) => {}

  const onChangeDatePicker = (value:any) => {
    let month:number = value.month() + 1
    let year:number = value.year() 
    let formatDate = dayjs(`${year}/${month}/01`)
    setCurrentDate(formatDate)
    disableDate(formatDate)
  }

  const handleClickChangeMonth = (isPrev:Boolean) => {
    let month:number = isPrev ? currentDate.month() : currentDate.month() + 2
    let year:number = currentDate.year() 
    let formatDate = dayjs(`${year}/${month}/01`)
    setCurrentDate(formatDate)
    disableDate(formatDate)
  }
  
  return (
    <div>
      <div className={styles.headerPicker}>
      <img className={styles.icon} src={prevImg} alt="prev" onClick={() => handleClickChangeMonth(true)}/>
        <DatePicker 
          picker="month" 
          allowClear={false} 
          defaultValue={currentDate} 
          value={currentDate} 
          onChange={onChangeDatePicker}
          format={common.DATE_PICKER_TITLE}
          />
      <img className={styles.icon} src={nextImg} alt="next" onClick={() => handleClickChangeMonth(false)}/>
      </div>
      <div className={styles.MonthCalendar}>
        <Calendar onPanelChange={onPanelChange} 
          // validRange={[minYear, maxYear]} 
          dateCellRender={dateCellRender} 
          disabledDate={disableDate} 
          onChange={changeDate} 
          onSelect={onSelect}
          value={currentDate}
          />
      </div>
    </div>
  );
}
