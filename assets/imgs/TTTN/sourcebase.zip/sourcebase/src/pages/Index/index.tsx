import React from 'react';
export default () => {
  return (
    <div>
      <h1>Index</h1>
    </div>
  );
};
