## Getting Started

Install dependencies,

```bash
$ yarn
$ npm
```

copy content .env.example to .env

Start the dev server,

```bash
$ yarn start
or npm start
```

Build production,

```bash
$ yarn build
```

react query tutorial: https://react-query.tanstack.com/
